//
// This is only a SKELETON file for the 'Minesweeper' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const sum = ([]) => {
  return [] + [];
  // todo: implement
};

let numberArray = []
export const range = (start, end, step) => {
  // todo: implement
  for(let numberArray of numberArray){
    return numberArray;
  }

};