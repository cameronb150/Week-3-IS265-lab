module.exports = {
  presets: ['@exercism/babel-preset-javascript'],
  plugins: [],
};
