module.exports = {
    reporters: [ "default", "jest-junit" ],
    transform: {
        "^.+\\.(js|jsx)$": "babel-jest",
    }
};